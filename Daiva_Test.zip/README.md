# [DAIVA PROJECT](http://www.daiva.com)

Hi! Let me introduce you a new Web Experience, the web portfolio of a big friend of mine, he is an Spiritual Artist who uses the energy of the environment to develop the human potential. He has created a whole new concept for many Spa's and Holistic Centers in Latin America. You can check out his work in this page.


## Introduction

I will ask him to write a short introduction here, have patience.


## Features

* Many great interactions and animations to create the Experience.


## Documentation

Here there will be the list of libraries that I used for the project


## Enjoy